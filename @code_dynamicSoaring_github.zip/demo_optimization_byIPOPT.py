## ==================================================================== ##
## solved by IPOPT
## manual of pyomo https://pyomo.readthedocs.io/en/stable/
## refer to Boundary layer dynamic soaring for autonomous aircraft Design and validation
## ==================================================================== ##

from math import acos, pi, sin, sqrt
from mpl_toolkits.mplot3d import Axes3D
import time
import numpy as np
import pandas as pd
import pyomo.environ as pyo
import matplotlib.pyplot as plt

if __name__ == '__main__':
    
    ## ==================================================================== ##
    ## ============ Basic Physical Parameters ============================= ##
    ## ==================================================================== ##
    varNum = 6 # 6 state parameters s = [𝑣, 𝛾, 𝜓, 𝑥, 𝑦, 𝑧]
    cvarNum = 2 # 2 control parameters u = [𝐶_𝐿, 𝜙]
    N = 101 # discretization
    path_bird_info = "bird_info.csv" # bird information
    data = pd.read_csv(path_bird_info,sep=',',encoding="gbk").values[0::,0::]
    species_num = 1 # 1 for albatross
    m = float(data[species_num,1]) # bird's mass
    S = float(data[species_num,2]) # bird's wing area
    AR = float(data[species_num,3]) # bird's aspect ratio
    fmax = float(data[species_num,4]) # bird's maximum lift-to-drag ratio
    nmax = float(data[species_num,5]) # bird's maximum load factor
    CD0 = float(data[species_num,6]) # profile drag coefficient
    g = float(data[species_num,7]) # gravity acceleration
    rho = float(data[species_num,8]) # air density
    Vc = sqrt(m*g/(0.5*rho*S)) # characteristic velocity
    Lc = Vc**2/g # characteristic length
    tc = Vc/g # characteristic time
    # travelSpeed_min = 3 / Vc # minimum travelling speed
    h0 = 0.03 / Lc # reference height0 for wind model
    href_num = 10.00 # reference height1 for wind model, with dimensions, m
    d_href = 0.00 # delta reference height, with dimensions, m
    d_href_ref = 0.00 # delta reference height for initialization, with dimensions, m  
    wref_num = 7.00 # initial wind velocity, with dimensions, m/s
    d_wref = 0.20 # delta wind velocity, with dimensions, m/s
    d_wref_ref =  0.00 # delta wind velocity for initialization, with dimensions, m/s
    wref_max = 25 - d_wref # maximum reference wind velocity
    angle_num = 120.00 # target direction angle
    d_angle = 0.00 # delta  target direction angle
    num1,num2 = str(angle_num).split('.')
    path_data = "data_angle_" + num1.rjust(3,'0') + "_" + num2.rjust(2,'0')
    path_output = path_data + "\\data_output"
    while(wref_num >= 0 and wref_num <= wref_max):
        ## ==================================================================== ##
        ## ============ set variables ========================================= ##
        ## ==================================================================== ##
        model = pyo.ConcreteModel() # optimization model
        ## ============ optimization varibales ============ ##
        vname = []
        for i in range(N):
            vname.append("v_"+str(i))
            vname.append("gamma_"+str(i))
            vname.append("psi_"+str(i))
            vname.append("x_"+str(i))
            vname.append("y_"+str(i))
            vname.append("z_"+str(i))
            vname.append("CL_"+str(i))
            vname.append("phi_"+str(i))
        vname.append("T")
        model.A = pyo.Set(initialize=vname)
        ## ============ range of variables ============ ##
        lb,ub = dict.fromkeys(vname),dict.fromkeys(vname)
        for i in range(N):
            lb["v_"+str(i)], ub["v_"+str(i)] = 0, 30/Vc
            lb["gamma_"+str(i)], ub["gamma_"+str(i)] = -pi/2, +pi/2
            lb["psi_"+str(i)], ub["psi_"+str(i)] = -pi, +pi
            lb["x_"+str(i)], ub["x_"+str(i)] = -200/Lc, +200/Lc
            lb["y_"+str(i)], ub["y_"+str(i)] = -1000/Lc, +1000/Lc
            lb["z_"+str(i)], ub["z_"+str(i)] = 0.5/Lc, +50/Lc
            lb["CL_"+str(i)], ub["CL_"+str(i)] = -0.2, 1.5
            lb["phi_"+str(i)], ub["phi_"+str(i)] = -pi/2*8/9, pi/2*8/9
        lb["T"],ub["T"] = 0, 20/tc
        ## ============ variables to model ============ ##
        def fb(model, i):
            return (lb[i], ub[i])
        model.var = pyo.Var(model.A, domain=pyo.Reals, bounds=fb)# print(model.var)
        ## ============ initialization ============ ##
        ## ============ V1 refer to Boundary layer dynamic soaring for autonomous aircraft Design and validation  ##
        T_initial = 7/tc
        model.var["T"] = T_initial
        # model.var["w_ref"].value = 8.6/Vc
        for i in range(N):
            model.var["x_"+str(i)].value = 13.75*i/N*T_initial / Lc
            model.var["y_"+str(i)].value = 13.75*i/N*T_initial / Lc
            model.var["z_"+str(i)].value = 8 / Lc
            model.var["v_"+str(i)].value = (20.625 + 6.875*np.cos(2*pi*i/N)) / Vc
            model.var["gamma_"+str(i)].value = 2*pi/9*sin(2*pi*i/N)
            model.var["psi_"+str(i)].value = pi/2*sin(2*pi*i/N)
            model.var["CL_"+str(i)].value = 0.65
            model.var["phi_"+str(i)].value = -4*pi/9 + 8*pi/9*sin(pi*i/N)
        ## ============ V2 refer to the previous solution ##
        # num1,num2 = str(round(wref_num+d_wref_ref,2)).split('.')
        # file = open(path_output + "\\wref_" + num1.rjust(2,'0') + "_" + num2.ljust(2,'0')+".dat")
        # file.readline()
        # matrix = np.reshape([float(x) for x in file.read().strip().split()],(-1,9))
        # t,v,gamma,psi,x,y,z,CL,phi = matrix[:,0],matrix[:,1],matrix[:,2],matrix[:,3],matrix[:,4],matrix[:,5],matrix[:,6],matrix[:,7],matrix[:,8]
        # T = t[-1]
        # model.var["T"] = T / tc
        # for i in range(N):
        #     model.var["x_"+str(i)].value = x[i] / Lc + 0 / Lc
        #     model.var["y_"+str(i)].value = y[i] / Lc 
        #     model.var["z_"+str(i)].value = z[i] / Lc + 0 / Lc
        #     model.var["v_"+str(i)].value = v[i] / Vc
        #     model.var["gamma_"+str(i)].value = gamma[i]
        #     model.var["psi_"+str(i)].value = psi[i]
        #     model.var["CL_"+str(i)].value = CL[i]
        #     model.var["phi_"+str(i)].value = phi[i]


        ## ==================================================================== ##
        ## ============ optimization target =================================== ##
        ## ==================================================================== ##
        # model.OBJ = pyo.Objective(expr = model.var["w_ref"], sense=pyo.minimize)
        # model.OBJ = pyo.Objective(expr = model.var["T"], sense=pyo.minimize)
        model.OBJ = pyo.Objective(expr = (model.var["x_"+str(N-1)]**2 + model.var["y_"+str(N-1)]**2)/(model.var["T"]**2), sense=pyo.maximize)


        ## ==================================================================== ##
        ## ============ constraints =========================================== ##
        ## ==================================================================== ##
        ## ============ wind model ============ ##
        wref_num = round(wref_num + d_wref,2)
        wref = wref_num / Vc # update wind velocity
        href_num = round(href_num + d_href,2)
        href = href_num / Lc # update reference height
        def w_velocity(height): # nondimensional wind velocity
            # return model.var["w_ref"] * height / href_num # linear wind model
            # return model.var["w_ref"] * pyo.log(height/h0) / pyo.log(href_num/h0)
            return wref * pyo.log(height/h0) / pyo.log(href/h0) # log wind model
        def wdot(height): # nondimensional wind velocity gradient
            # return model.var["w_ref"] / href_num # linear wind model
            # return  model.var["w_ref"] * 1 / height / pyo.log(href_num/h0)
            return wref * 1 / height / pyo.log(href/h0)
        ## ============ EOM ============ ##
        def EOM(stemp,utemp):
            [v,gamma,psi,x,y,z] = stemp
            [CL,phi] = utemp
            CD = CD0 + CL**2/(pi*AR)
            xdot = v*pyo.cos(gamma)*pyo.cos(psi)
            ydot = v*pyo.cos(gamma)*pyo.sin(psi) - w_velocity(z)
            zdot = v*pyo.sin(gamma)
            vdot = - CD*v**2 - pyo.sin(gamma) + wdot(z)*zdot*pyo.cos(gamma)*pyo.sin(psi)
            gammadot = (CL*v**2*pyo.cos(phi) - pyo.cos(gamma) - wdot(z)*zdot*pyo.sin(gamma)*pyo.sin(psi)) / v
            psidot = (CL*v**2*pyo.sin(phi) + wdot(z)*zdot*pyo.cos(psi)) / (v*pyo.cos(gamma))
            return [vdot,gammadot,psidot,xdot,ydot,zdot]
        ## ============ setup of constraints ============ ##
        model.eqn = pyo.ConstraintList()
        for i in range(1, N): # start from 1 to avoid negative values
            um,si,si_1,ui,ui_1,sm = [],[],[],[],[],[]
            si.append(model.var["v_"+str(i)])
            si.append(model.var["gamma_"+str(i)])
            si.append(model.var["psi_"+str(i)])
            si.append(model.var["x_"+str(i)])
            si.append(model.var["y_"+str(i)])
            si.append(model.var["z_"+str(i)])
            si_1.append(model.var["v_"+str(i-1)])
            si_1.append(model.var["gamma_"+str(i-1)])
            si_1.append(model.var["psi_"+str(i-1)])
            si_1.append(model.var["x_"+str(i-1)])
            si_1.append(model.var["y_"+str(i-1)])
            si_1.append(model.var["z_"+str(i-1)])
            ui.append(model.var["CL_"+str(i)])
            ui.append(model.var["phi_"+str(i)])
            ui_1.append(model.var["CL_"+str(i-1)])
            ui_1.append(model.var["phi_"+str(i-1)])
            um.append(1/2*(model.var["CL_"+str(i)]+model.var["CL_"+str(i-1)]))
            um.append(1/2*(model.var["phi_"+str(i)]+model.var["phi_"+str(i-1)]))
            fi = EOM(si,ui)
            fi_1 = EOM(si_1,ui_1)
            for j in range(varNum):
                sm.append(1/2*(si[j]+si_1[j])-1/8*(fi[j]-fi_1[j])*1/(N-1)*model.var["T"])
            fm = EOM(sm,um)
            model.eqn.add(expr = model.var["v_"+str(i)]-model.var["v_"+str(i-1)]-1/6*(fi[0]+4*fm[0]+fi_1[0])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add(expr = model.var["gamma_"+str(i)]-model.var["gamma_"+str(i-1)]-1/6*(fi[1]+4*fm[1]+fi_1[1])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add(expr = model.var["psi_"+str(i)]-model.var["psi_"+str(i-1)]-1/6*(fi[2]+4*fm[2]+fi_1[2])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add(expr = model.var["x_"+str(i)]-model.var["x_"+str(i-1)]-1/6*(fi[3]+4*fm[3]+fi_1[3])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add(expr = model.var["y_"+str(i)]-model.var["y_"+str(i-1)]-1/6*(fi[4]+4*fm[4]+fi_1[4])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add(expr = model.var["z_"+str(i)]-model.var["z_"+str(i-1)]-1/6*(fi[5]+4*fm[5]+fi_1[5])*1/(N-1)*model.var["T"] == 0)
            model.eqn.add( expr = model.var["v_"+str(i)]**2*model.var["CL_"+str(i)] - nmax <= 0) # over load
            # model.eqn.add(expr = model.var["CL_"+str(i)]-model.var["CL_"+str(i-1)] <= 0.1)
            # model.eqn.add(expr = model.var["CL_"+str(i)]-model.var["CL_"+str(i-1)] >= -0.1)
            # model.eqn.add(expr = model.var["phi_"+str(i)]-model.var["phi_"+str(i-1)] <= 0.3)
            # model.eqn.add(expr = model.var["phi_"+str(i)]-model.var["phi_"+str(i-1)] >= -0.3)
        model.eqn.add(expr = model.var["v_"+str(0)] - model.var["v_"+str(N-1)] == 0) # v0 = vN_1
        model.eqn.add(expr = model.var["psi_"+str(0)] - model.var["psi_"+str(N-1)]  == 0) # psi0 - psiN_1 = 0
        model.eqn.add(expr = model.var["gamma_"+str(0)] - model.var["gamma_"+str(N-1)] == 0) # gamma0 = gammaN_1
        model.eqn.add(expr = model.var["x_"+str(0)] == 0) # x0 = 0
        model.eqn.add(expr = model.var["y_"+str(0)] == 0) # y0 = 0
        # model.eqn.add(expr = model.var["z_"+str(0)] == 1.5/Lc) # z0
        # model.eqn.add(expr = model.var["x_"+str(0)]-model.var["x_"+str(N-1)] == 0) # x0 = xN_1
        # model.eqn.add(expr = model.var["y_"+str(N-1)] >= 40/Lc)
        model.eqn.add(expr = model.var["x_"+str(N-1)] >= -0.1/Lc) # Set the endpoint in the first quadrant or the fourth quadrant.
        model.eqn.add(expr = model.var["y_"+str(N-1)] <= 0/Lc) # Set the endpoint in the first quadrant or the fourth quadrant.
        model.eqn.add(expr = model.var["z_"+str(0)]-model.var["z_"+str(N-1)] == 0) # z0 = zN_1
        # model.eqn.add(expr = (model.var["x_"+str(N-1)]**2 + model.var["y_"+str(N-1)]**2) >= (travelSpeed_min*model.var["T"])**2 )
        model.eqn.add(expr = model.var["x_"+str(N-1)]-model.var["x_"+str(0)] == pyo.tan((angle_num - d_angle)/180*pi) * (model.var["y_"+str(N-1)]-model.var["y_"+str(0)]) )


        ## ==================================================================== ##
        ## ============ solve by IPOPT  ============================================= ##
        ## ==================================================================== ##
        path =  "Solver//ipopt-win64//ipopt.exe"# IPOPT solver location
        print("processing ...")
        time_start = time.time()
        pyo.SolverFactory('ipopt', executable=path).solve(model)
        time_end = time.time()
        print('CPU excutation time: ' + str(time_end-time_start))


        ## ==================================================================== ##
        ## ============ print and save ======================================== ##
        ## ==================================================================== ##
        print("wref:" + str(wref*Vc))
        print("T:" + str(model.var['T']()*tc))
        travelSpeed = sqrt((model.var["x_"+str(N-1)]()**2 + model.var["y_"+str(N-1)]()**2)/(model.var["T"]()**2)) * Vc
        print("travelling speed:" + str(travelSpeed))
        print("optimization object value:" + str(sqrt(model.OBJ())*Vc))
        deltaY = model.var["y_"+str(N-1)]() - model.var["y_"+str(0)]()
        deltaX = model.var["x_"+str(N-1)]() - model.var["x_"+str(0)]()
        angle_temp = round(acos(deltaY/sqrt(deltaX**2+deltaY**2))/pi*180,2)
        print("angle_temp:" + str(angle_temp))
        print("angle_target: " + str(angle_num - d_angle))
        if(angle_temp != round(angle_num,2) - d_angle):
            print("Error ...")
            input()
        num1,num2 = str(wref_num).split('.')
        # f = open(path_output + "\\wref_"  + num1.rjust(2,'0') + "_" + num2.ljust(2,'0')+".dat","w")
        f = open("results.dat","w")
        f.write("variables=t,v,gamma,psi,x,y,z,CL,phi\n")
        for i in range(N):
            f.write( str(i/(N-1)*model.var["T"]() * tc) + '\t')
            f.write( str(model.var["v_"+str(i)]() * Vc) + '\t')
            f.write( str(model.var["gamma_"+str(i)]()) + '\t')
            f.write( str(model.var["psi_"+str(i)]()) + '\t')
            f.write( str(model.var["x_"+str(i)]() * Lc) + '\t')
            f.write( str(model.var["y_"+str(i)]() * Lc) + '\t')
            f.write( str(model.var["z_"+str(i)]() * Lc) + '\t')
            f.write( str(model.var["CL_"+str(i)]()) + '\t')
            f.write( str(model.var["phi_"+str(i)]()) + '\t')
            f.write('\n')
        f.close()